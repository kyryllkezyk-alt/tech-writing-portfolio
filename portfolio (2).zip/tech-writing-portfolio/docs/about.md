# About

I'm Kyryll Kezyk, a localization and language quality specialist based in northern Israel, now
working as a technical writer.

My background:

- **Hebrew division management.** I ran a network of freelance linguists and wrote the onboarding
  material, client guidelines, and process documentation they worked from.
- **Language quality.** LQA and LQE for global vendors, including reviewer guidelines and error
  typologies.
- **AI evaluation.** Rating and annotating model output against detailed evaluation frameworks.
- **Freelance localization.** Legal, medical, technical, and media content through my company,
  K-DOCS.

## What I bring to a docs team

- **Writing for translation.** I write source text that localizes cleanly, because I've spent years
  on the receiving end of text that didn't.
- **Right-to-left expertise.** Hebrew and Arabic layout, bidirectional text, and the edge cases that
  break UI strings.
- **Quality systems.** Style guides, terminology management, review workflows, and measurable
  quality metrics.
- **Docs-as-code.** This site: Markdown in Git, MkDocs, GitHub Actions, and Vale prose linting.

## Languages

Hebrew, Russian, and Ukrainian at native level; English, Italian, and Dutch at C2.

## Tools

| Area | Tools |
| --- | --- |
| Docs | Markdown, MkDocs, Git, GitHub Actions, Vale |
| Localization | Trados Studio, memoQ, Phrase, Smartcat, XTM, Crowdin, Lokalise |
| Operations | Plunet |

## Education

- B.A. Philosophy of Language and Linguistics, University of Haifa
- M.Sc. Information Systems
- M.Sc. Applied Economics

## Contact

[mainoffice@k-docs.com](mailto:mainoffice@k-docs.com) ·
[k-docs.com](https://k-docs.com) ·
[LinkedIn](https://www.linkedin.com/in/kyryll-kezyk-5a564336)
