# Technical writing portfolio

For 15 years I've worked on the receiving end of documentation: translating and reviewing
software, legal, and medical content, and running the Hebrew teams that localized it. I've seen
every way a source text breaks in translation, and I've written the style guides, glossaries, and
reviewer guidelines that kept it from breaking.

This portfolio shows what I write when I own the source.

**This site is itself the sample.** Every page is version-controlled Markdown, linted on pull
request, built with `mkdocs build --strict`, and deployed by GitHub Actions on merge.

## Where to start

<div class="grid cards" markdown>

-   **Writing samples**

    ---

    Seven documents, seven genres: tutorial, API reference, how-to, concept, release notes,
    troubleshooting, runbook.

    [:octicons-arrow-right-24: Browse samples](samples/index.md)

-   **Standards**

    ---

    The style guide, terminology policy, and pipeline I set up when I own a docs function.

    [:octicons-arrow-right-24: Read the style guide](standards/style-guide.md)

-   **Case studies**

    ---

    Two documentation problems with the outcome they produced.

    [:octicons-arrow-right-24: Read case studies](case-studies/quality-audit.md)

-   **About me**

    ---

    Background, languages, tools, and how to reach me.

    [:octicons-arrow-right-24: About](about.md)

</div>

!!! note "About the product in these samples"
    The samples document **Lingua**, a fictional localization platform invented for this
    portfolio. No client-confidential material appears on this site.
